export default function locations(state = {list: [], status: null}, action) {
    switch (action.type) {
      case 'LOADING_LOCATIONS':
        return {list: [], status: "Fetching locations..."}
      case 'LOCATIONS_FETCHED':
        action.locations.status = null;
        return {list: action.locations, status: null}
      case 'ERROR_LOADING_LOCATIONS':
        return {list: [], status: "Error fetching locations"}
      default:
        return state
    }
  }