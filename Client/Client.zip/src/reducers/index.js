import { combineReducers } from 'redux'
import locations from './locations'
import location from './location'
import { loginStatus } from './loginStatus'

const mockbnbApp = combineReducers({
        loginStatus, 
        locations,
        location,
    })

export default mockbnbApp