export const loginStatus = (state = {userDetails: {}, loginStatus: ""}, action) => {
    switch (action.type) {
        case 'LOGIN_USER':
            return {userDetails: action.userDetails, loginStatus: "logged in"};
        case 'LOGOUT_USER':
            return {userDetails: {}, loginStatus: "logged out"};
        case 'LOGIN_ERROR':
            return {...state, loginStatus: "Error logging in"};
        default:
            return state;
    }
}