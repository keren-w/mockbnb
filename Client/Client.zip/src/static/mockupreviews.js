 const mockupReviews = [
    {   
        id: 1,
        photo: "https://randomuser.me/api/portraits/women/93.jpg",
        userId: "Keren",
        date: new Date('2015-03-25'),
        title: "Beautiful appartment, hospiting guests",
        revContent: "Anna was an excellent host, very clear and quick with communication. The trullo is very clean, though most pleasant to sit outside so not great in bad weather. It’s in beautiful countryside and nearby cisternino is very nice.",
        rating: 5      
    },
    {
        id: 2,
        photo: "https://randomuser.me/api/portraits/women/73.jpg",
        userId: "Maya",
        date: new Date('2017-12-17'),
        title: "My best stay ever!",
        revContent: "Can't say enough about our trulli stay at Anna's. We were concerned because our first experience in Ravello was not the best intro to Italian airbnb, as there wasn't anything for a traveler just arriving in Ravello, no soap, just a few sheets of toilet paper, no welcome bottle of water. We changed our airbnb plans for the trip and stayed in hotels until we got to Anna's trulli. It was packed with all a home could have and more! Her mother gave us a jar of homemade cherry jam, farm eggs, orange juice, etc. I have an airbnb and have learned to offer more than normally expected because I am aware that a traveler may not have the opportunity to buy even basic supplies before arrival. At Anna's this was nit the case. The trulli is close to Ostuni, nearby to Cisternina, but central to visit many beautiful towns. We hope to return with family someday!",
        rating: 3,  
    }
]

export default mockupReviews;