import React, { Component} from 'react';
import {connect} from 'react-redux';
import {isEmpty} from '../../components/Utilities';
import styled from 'styled-components';
import {getDataFromServer} from '../../actions';
import LocationPreview from '../../components/LocationPreview';

class Locations extends Component {
    constructor() {
        super()
    }

    componentDidMount() {
        this.props.getLocations(); //dispatches the locations getter
    }
    
   render() {
    let locations = this.props.locations.list;
    
    let previewItems =  locations.length > 0 ? 
        (locations.map(item => { return <LocationPreview key={item._id} item={item}/>})) :
        <p>{this.props.locations.status}</p>

    return (
        <div>
            <FeaturedLocationsTitle>Featured Locations</FeaturedLocationsTitle>
            <LocationsContainer>
                {previewItems}
            </LocationsContainer>
        </div>
    )
   }
}

const LocationsContainer = styled.div`
    max-width: 85vw;
    max-height: 120%;
    margin: 0 auto;
    padding: 15px;
    box-sizing: border-box;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    grid-gap: 15px;

    @media (max-width:1130px)  {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    }

    @media (max-width:641px) and (min-width: 320px) {
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    }
`;

const FeaturedLocationsTitle = styled.h2`
    max-width: 85vw;
    margin: 0 auto;
    padding: 15px;
    box-sizing: border-box;
    margin-top: 0;
    color: #484848;
`;

function mapStateToProps({loginStatus, locations}) {
	return {loginStatus, locations};
}

function mapDispatchToProps(dispatch) {
    return {
        getLocations: () => {dispatch(getDataFromServer('/api/locations', "LOCATIONS"))}
    }
}

export default connect(mapStateToProps , mapDispatchToProps)(Locations)