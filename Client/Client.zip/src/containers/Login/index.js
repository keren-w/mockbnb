import React, {Component} from 'react';
import {connect} from 'react-redux';
import {setLogin} from '../../actions';
import styled from 'styled-components';
import {Button} from '../../components/Utilities';

class Login extends Component {
    constructor() { 
        super();
        this.handleLoginSubmit = this.handleLoginSubmit.bind(this);
    }

    handleLoginSubmit() {
        let username = this.$username.value;
        let password = this.$password.value;
        this.props.SendLoginDetails({username, password});
        this.props.history.push('/')
    }

   render() {
       
    console.log(this.props)
        return (    
            <div>
                <ModalContainer>
                    <input type="text" placeholder="Username" ref={(el) => { this.$username = el }} />
                    <input type="password" placeholder="Password" ref={(el) => { this.$password = el }} />
                    <Button onClick={this.handleLoginSubmit} >Log In</Button>
                </ModalContainer>
            </div>
        )
   }
}

const ModalContainer = styled.div`
    width: 400px;
    margin: 0 auto;
    margin-top: 20vh;

    >input {
        display: block;
        width: 100%;
        padding: 12px;
        margin: 15px 0;
        box-sizing: border-box;
    }

    @media screen and (max-width: 560px) {
        max-width: 75vw;
    }
`;

function mapStateToProps({loginStatus}) {
	return {loginStatus};
}

function mapDispatchToProps(dispatch) {
    return {
        SendLoginDetails: (loginDetails) => {dispatch(setLogin(loginDetails))}
    }}

export default connect(mapStateToProps, mapDispatchToProps)(Login)