import React, {Component} from 'react';
import styled from 'styled-components';
import {Link} from 'react-router-dom';

export default () => {
   return (
        <div>
            <RegularUserMenu />
            <MinifiedUserMenu />
        </div>
    )    
}

const RegularUserMenu = () => {
    let linkStyle = { textDecoration: 'none', fontWeight: 600, padding: '0 16px'};
    return (
        <RegularNav>
            <ul>
                <li>Become a Host</li>
                <li>Help</li>
                <li>Sign Up</li>
                <Link to='/login' style={linkStyle}><li>Log In</li></Link>
            </ul>
        </RegularNav>
    )
}

const RegularNav = styled.nav`
    display: block;
    height: 100%;

    >ul {
        list-style-type: none;
        display: flex;
        align-items: center;
        height: 100%;
        padding: 0;
        margin: 0;
    }

    >ul>li {
        padding-left: 15px;
        padding-right: 15px;
        color: #484848;
        display: inline-block;
        font-size: 13px;
        font-weight: 600;
        vertical-align: center;
    }

    @media screen and (max-width: 550px) {
        display: none;
    }
`;

class MinifiedUserMenu extends Component {
    constructor() {
        super();
        this.state = {menuOn: false}
        this.handleToggleMenu = this.handleToggleMenu.bind(this);
        this.turnMenuOff = this.turnMenuOff.bind(this);
    }

    turnMenuOff() {
        this.setState({menuOn: false});
    }

    handleToggleMenu() {
        var newMenuState = !(this.state.menuOn);
        this.setState({menuOn: newMenuState});
    }
    
    render() {
        let linkStyle = { textDecoration: 'none', fontWeight: 600, padding: '0 16px', padding: '5px 15px'};
        var toggleMenu = this.state.menuOn && (<ul>
            <li>Become a Host</li>
            <li>Help</li>
            <li>Sign Up</li>
            <Link to='/login' style={linkStyle} onClick={this.turnMenuOff}><li>Log In</li></Link>
            </ul>)
    
        return (
            <MinifiedNav>
                <i className="fa fa-bars fa-2x" aria-hidden="true" onClick={this.handleToggleMenu}></i>
                {toggleMenu}
            </MinifiedNav>
         )
    }
}

const MinifiedNav = styled.nav`
display: none;
height: 100%;
position: relative;
color: #484848;

>i {
    height: 100%;
    width: 2em;
    display: flex;
    justify-content: space-around;
    align-items: center;
}

>ul {
    list-style-type: none;
    display: flex;
    direction: rtl;
    flex-direction: column;
    background: white; 
    padding: 0;
    margin: 0;
    position: absolute;
    right: 0;
    top: 100%;
    border: 1px solid lightgray;
    border-top: none;
}

>ul>li{
    font-size: 13px;
    font-weight: 600;
    padding: 5px 15px;
    border-bottom: 0.5px solid red;
}

>ul>li:hover {
    background: lightgray;
}

@media screen and (max-width: 550px) {
    display: block;
}
`;