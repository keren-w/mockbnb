import React from 'react';
import styled from 'styled-components';
import Locations from '../../containers/Locations/';

export default ({items}) => {
    return (
        <div>
            <Locations />
        </div>
    )
}