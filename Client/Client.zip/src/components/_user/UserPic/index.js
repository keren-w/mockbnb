import React from 'react';
import styled from 'styled-components';

function UserPicMedium ({}) {}

function UserPicSmall({userPic, userName}) {
   return <SmallUserPic src={userPic} alt={userName}/>
}

function UserThumbnail({owner}) {
    return (
        <Thumbnail>
            <img src={owner.imageUrl} />
            <p>{owner.name}</p>
        </Thumbnail>
    )
}

const Thumbnail = styled.div`
    width: 64px;
    display: flex;
    flex-direction: column;
    text-align: center;
    margin: 0 30px;

    >img {
        height: 64px;
        border-radius: 50%;
    }
`;

const SmallUserPic = styled.img`
    width: 48px;
    border-radius: 50%;
    padding: 15px;
`;

export {UserPicMedium, UserPicSmall, UserThumbnail}