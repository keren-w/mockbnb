import React, { Component } from 'react';
import {Route, Redirect} from 'react-router-dom';
import HomePage from '../HomePage/';
import Location from '../../containers/Location';
import TopBar from '../../containers/TopBar';
import Login from '../../containers/Login';

class App extends Component {
    constructor() {
        super()
        this.handleSuccesfulLogin = this.handleSuccesfulLogin.bind(this);
        this.handleLogOut = this.handleLogOut.bind(this);
    }

    handleSuccesfulLogin(userDetails) {
        this.setState({loggedIn: userDetails});
    }

    handleLogOut() {
        this.setState({loggedIn: null})
    }

    render() {
        let notFoundStyle = {width: '75vw', margin: '20vh auto' }
        return (
             <div>
                <TopBar />
                <Route exact path="/" component={HomePage}/>
                <Route path="/locations/:id" component={Location} />
                <Route path="/login" render={({history}) => <Login history={history} updateLoginStatus={this.handleSuccesfulLogin}/>} />
                <Route path="/logout" render={() => {
                    return (<Redirect to="/"/>)
                }} />
                </div>  
        )
    }
}
 
export default App