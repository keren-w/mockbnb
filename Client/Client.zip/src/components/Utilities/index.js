import React from 'react';
import styled from 'styled-components';

const Button = styled.button`
width: 100%;
padding: 9px 27px;
border-radius: 4px;
border: none;
font-size: 1.2rem;
font-weight: 900;
background: rgb(255, 126, 130);
color: white;
`;

const isEmpty = (obj) => {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop))
            return false
    }
    return true
}

module.exports = {Button, isEmpty};